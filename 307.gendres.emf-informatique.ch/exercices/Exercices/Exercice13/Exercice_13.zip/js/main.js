document.onreadystatechange = function () {
  // Code exécuté lorsque la page a terminé d'être chargée.
  if (document.readyState === "complete") {
    // Chargement de l'éventuelle cookie.
    getCookie();
    // Ajout d'un écouteur "click" sur le bouton "enregistrer".
    document.getElementById("enregistrer").addEventListener("click", saveData);
  }
};

function saveData() {
  // Récupérer les valeurs contenues dans les champs "prenom" et "nom".
  //
  // Créer un objet json "personneJson" contenant le prénom et le "nom".
  //
  // Convertir l'objet json "personneJson" en chaine de caractère.
  //
  // Appeler la méthode "setCookie" en passant en paramètre l'objet "personneJson" converti et en précisant le délai de 3 minutes.
  //
}

function setCookie(contenu, minutes) {
  // Générer une date d'expiration. Il doit s'agir de la date et l'heure actuelle + le nombre de minute passé en paramètre.
  //

  // Créer le cookie.

  console.log("Data saved in cookie");
}

function getCookie() {
  // Tester la présence du cookie. Pour cela, il faut tester si la taille du cookie est supérieure à 0.
  if (document.cookie.length > 0) {
    // Récupérer le contenu du cookie et en extraire la partie qui se situe après le "="; Vous pouvez utiliser la méthode "split"
    // liée aux chaînes de caractères.
    //
    // Convertir la chaîne de caractères en objet Json.
    //
    // Charger les deux champs avec la valeur du prénom et du du nom contenu dans l'objet json.
    //
    console.log("Data retrieved from cookie");
  }
}
