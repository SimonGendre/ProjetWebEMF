/*
        Author: Philippe Galley
        Date: 01.04.2023
        Description: Exercice 16, fonctions jquery
*/

$(document).ready(function () {});
